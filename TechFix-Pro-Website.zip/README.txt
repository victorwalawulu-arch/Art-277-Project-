TECHFIX PRO WEBSITE PROJECT

FILES
index.html - Home page (keep this exact name)
about.html - About Us
services.html - Our Services
blog.html - Blog
gallery.html - Gallery
contact.html - Contact Us
styles.css - One shared stylesheet for all pages
script.js - Shared JavaScript file
images/ - Add your own photos here

VIEW THE WEBSITE
1. Extract this ZIP file.
2. Open the techfix-pro folder.
3. Open index.html in a web browser.
4. Use the navigation menu to move between pages.

UPLOAD TO GITHUB PAGES
1. Create a GitHub repository.
2. Upload all files and the images folder.
3. Open repository Settings, then Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Wait for publishing. GitHub Pages uses index.html as the home page.

IMPORTANT
- The website uses Google Fonts and Font Awesome CDN links, so an internet connection is needed for those fonts and icons.
- Replace hello@techfixpro.com, the sample phone number and location with real business contact details.
- The contact form is a front-end demo. It does not deliver messages until connected to a form service or backend.
- The gallery currently uses sample icons. Add your own images to the images folder.
- All six pages share styles.css and each page includes a small style block, matching the lesson structure.
